﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Glostest.ViewModels
{
    public class CreateWordPairView
    {
        public int WordId1 { get; set; }
        public int WordId2 { get; set; }
    }
}