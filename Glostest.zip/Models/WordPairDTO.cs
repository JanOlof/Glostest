﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Glostest.Models
{
    public class WordPairDTO
    {
        public int Id { get; set; }
        public string Word1 { get; set; }
        public string Word2 { get; set; }
    }
}